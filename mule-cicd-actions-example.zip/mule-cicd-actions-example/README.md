# mule-cicd-actions-example
Sample project to showcase the use of CICD with Github Actions, completing the deployment to Cloudhub (Anypoint Platform)
